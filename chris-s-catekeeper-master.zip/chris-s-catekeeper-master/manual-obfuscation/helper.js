const Discord = require("discord.js");
function a(a) {
    return a.guild.member(a.author);
}
exports.m = a;