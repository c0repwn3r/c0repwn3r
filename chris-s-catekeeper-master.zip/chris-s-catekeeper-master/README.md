# chris-s-catekeeper
A custom discord bot for Sven's parkour

### Information
This code is owned by core and GhostlyCoding. You may have free access to the production code, however the obfuscation mappings are NOT public, for security reasons. You may NOT attempt to reverse-engineer this code.

### Can I have the obfuscation mappings?
No.

### How was the code obfuscated?
The code was obfuscated by hand, so don't get any ideas.
