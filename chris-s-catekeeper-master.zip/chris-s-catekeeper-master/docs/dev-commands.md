these can only be preformed by people with developer:true

.d gd CoreCuber - gets raw base64 playerdata

.d db64 - Translastes raw playerdata to json

.d eb64 - Encodes raw playerdata

.d sd CoreCuber - sets raw playerdata

.d tv - Toggle a player's VIP status (vip)

.d td - Toggle a player's Developer status (developer)

.d to - Toggle a player's Owner status (owner)

.d tm - Toggle a player's Moderator status (moderator)

.d b CoreCuber - Bans a player from using the bot

.d ub CoreCuber - Unbans a player from using the bot

.d gr CoreCuber <id> - Give a role to a user (disabled for non-moderators)
  
.d rr CoreCuber <id> - Remove a role from a user (disabled for non-moderators)
