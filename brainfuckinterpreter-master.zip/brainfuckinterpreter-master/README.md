# brainfuckinterpreter
A BF interpreter made by three bored nerds on discord.

# How does it work?
It dosen't.

# Really, how does it work?
Whatever, run 
```
interpreter --file <input some confusing file here>
```
and watch.

# Why did you make this?
...

# What is BF?
**activates Wikipedia mode**
Brainf*** is a esoteric...
nevermind here is the wikipedia article:
https://en.wikipedia.org/wiki/Brainfuck

# Build instructions?
Run either make-nix for macOS and \*nix, or make-win for win. Have g++ installed. It might work maybe.
