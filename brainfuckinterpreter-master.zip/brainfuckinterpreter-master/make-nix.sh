#!/bin/bash
echo Compiling for .nix systems (install g++ first please)
g++ main.cpp parser.cpp -o interpreter
echo That might have worked maybe idk whatever
